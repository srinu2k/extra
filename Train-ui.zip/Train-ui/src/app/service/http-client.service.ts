import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

export class Trains {
  constructor(
    public  train_id: number,
    public  train_name: String,
    public  from: String,
    public  to: String,
    public  fare: number,
  ) {
  }
}

@Injectable({
  providedIn: 'root'
})

export class HttpClientService{

  constructor(
    private http: HttpClient
  ) { }

  getTrains(){
      console.log('Test Call');
      return this.http.get<Trains[]>('http://localhost:8080/Trains');
  }
}